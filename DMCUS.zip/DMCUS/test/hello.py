print("hello world")
input()